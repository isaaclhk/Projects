# imports
import re
import numpy as np
from sklearn.utils._testing import ignore_warnings
from matplotlib import rcParams

import config 
from evaluate_utils import report, plot_combined_roc
from stack import Stack
from replicate_hunters import Hunters


@ignore_warnings(category=Warning)
def main():
    # set seed for reproducibility
    np.random.seed(config.random_state)
    
    # set matplotlib font
    rcParams['font.family'] = 'serif'
    rcParams['font.serif'] = ['Times New Roman']

    print('<< Replicating results from Hunters\' SNRPV >>')
          
    # create object
    hunters = Hunters()
    
    # get scaled data with selected features
    X_train, X_test, y_train, y_test = hunters.process_data()
    
    # generate predictions
    pred_train = hunters.predict_proba(X_train)
    pred_test = hunters.predict_proba(X_test)
    
    # report results
    train_stats, test_stats = report(y_train, y_test, pred_train, pred_test)
    train_fpr, train_tpr, train_mean_auc, train_lwr_auc, train_upr_auc = train_stats
    test_fpr, test_tpr, test_mean_auc, test_lwr_auc, test_upr_auc = test_stats

    print('<< Stacking Ensembles >>')

    # stacking model with pca and se
    stack = Stack(config)
    pipelines, param_distributions = stack.pipeline_builder()
    best_models_pcase, base_results_df_pcase = stack.hyperparam_search(pipelines, param_distributions)
    print(base_results_df_pcase.drop(columns = ['best_params']))
    stack.plot_base('AUC-ROC of base models (Training set)')
    stack.plot_base('AUC-ROC of base models (cross-validated)', cv = True)
    pred_train_pcase, pred_test_pcase = stack.stack_fit(best_models_pcase)
    
    # generate report
    print('/---- with PCA and SE ----/')
    _, _ = report(y_train, y_test, pred_train_pcase, pred_test_pcase)
    
    # stacking model with pca only
    print('/---- PCA only ----/')
    best_models_pca = {name: model for name, model in best_models_pcase.items() if re.search('pca', name)}
    predict_train_pca, predict_test_pca = stack.stack_fit(best_models_pca)
    
    # generate report
    train_pca_stats, test_pca_stats = report(
        y_train, y_test, predict_train_pca, predict_test_pca)
    
    # stacking model with sn-rpv vars
    print('/---- snrpv vars ----/')
    stack_snrpv = Stack(config, dim_reduce=False)
    pipelines_snrpv, param_distributions_snrpv = stack_snrpv.pipeline_builder()
    best_models_snrpv, base_results_df_snrpv = stack_snrpv.hyperparam_search(
        pipelines_snrpv, param_distributions_snrpv)
    print(base_results_df_snrpv.drop(columns = ['best_params']))
    stack_snrpv.plot_base('AUC-ROC of base models (Training set)')
    stack_snrpv.plot_base('AUC-ROC of base models (cross-validated)', cv = True)
    predict_train_snrpv, predict_test_snrpv = stack_snrpv.stack_fit(best_models_snrpv)
    
    # generate report
    train_snrpv_stats, test_snrpv_stats = report(
        y_train, y_test, predict_train_snrpv, predict_test_snrpv)
    
    # extract stats for plotting
    train_pca_fpr, train_pca_tpr, \
    train_pca_mean_auc, train_pca_lwr_auc, train_pca_upr_auc = train_pca_stats
    
    test_pca_fpr, test_pca_tpr, \
    test_pca_mean_auc, test_pca_lwr_auc, test_pca_upr_auc = test_pca_stats
    
    train_snrpv_fpr, train_snrpv_tpr, \
    train_snrpv_mean_auc, train_snrpv_lwr_auc, train_snrpv_upr_auc = train_snrpv_stats
    
    test_snrpv_fpr, test_snrpv_tpr, \
    test_snrpv_mean_auc, test_snrpv_lwr_auc, test_snrpv_upr_auc = test_snrpv_stats
    
    # plot roc curves (training set)
    print('-- Plotting combined AUC curves of final ensemble models--')
    
    plot_combined_roc(
    train_pca_fpr, train_pca_tpr, train_pca_mean_auc, train_pca_lwr_auc, train_pca_upr_auc,
    train_snrpv_fpr, train_snrpv_tpr, train_snrpv_mean_auc, train_snrpv_lwr_auc, train_snrpv_upr_auc,
    train_fpr, train_tpr, train_mean_auc, train_lwr_auc, train_upr_auc, 'training'
    )
    # plot roc curves (test set)
    plot_combined_roc(
    test_pca_fpr, test_pca_tpr, test_pca_mean_auc, test_pca_lwr_auc, test_pca_upr_auc,
    test_snrpv_fpr, test_snrpv_tpr, test_snrpv_mean_auc, test_snrpv_lwr_auc, test_snrpv_upr_auc,
    test_fpr, test_tpr, test_mean_auc, test_lwr_auc, test_upr_auc, 'test'
    )
    
if __name__ == '__main__':
    main()
