# imports
import pandas as pd
from sklearn.model_selection import RandomizedSearchCV
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import StackingClassifier
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import roc_curve, auc
from collections import defaultdict
import matplotlib.pyplot as plt

class Stack:
    def __init__(
        self, 
        config,
        train_dir = 'data/Features_Train.csv', 
        test_dir = 'data/Features_Test.csv',
        dim_reduce = True
        ):
        
        # config
        self.config = config
        
        # data
        train = pd.read_csv(train_dir)
        test = pd.read_csv(test_dir)

        self.X_train = train.drop(columns = ['ID','Outcome'])
        self.y_train = train['Outcome']

        self.X_test = test.drop(columns = ['ID','Outcome'])
        self.y_test = test['Outcome']

        # make column names consistent
        self.X_test.columns = list(self.X_train.columns)
        
        # dictionary of selected models
        self.best_models = {}
        
        # apply dimensionality reduction? (PCA or spectral embedding)
        self.dim_reduce = dim_reduce
        
    def pipeline_builder(self) -> tuple:
        '''
        Creates a dictionary of pipelines and another
        dictionary of their corresponding parameter distributions.
    
        returns:
            pipelines (dict): {pipeline_name: pipeline}
            param_distributions = {pipeline_name: hyperparams}
        '''
        # Create pipelines
        pipelines = {}
        param_distributions = {}
        
        models = self.config.models
        
        if self.dim_reduce:
            dim_reductions = self.config.dim_reductions
            dim_reduction_params = self.config.dim_reduction_params
            
            for dim_name, dim_reduction in dim_reductions.items():
                for model_name, (model, params) in models.items():
                    pipeline_name = f"{dim_name}_{model_name}"
                    pipelines[pipeline_name] = Pipeline([
                        ('scaler', StandardScaler()),
                        ('dim_reduction', dim_reduction),
                        ('classifier', model)
                    ])

                    # Combine with model-specific parameters
                    param_distributions[pipeline_name] = {**dim_reduction_params, **params}
        else:
            for model_name, (model, params) in models.items():
                pipeline_name = f"snrpv_{model_name}"
                pipelines[pipeline_name] = Pipeline([
                    ('scaler', StandardScaler()),
                    ('classifier', model)
                ])
                
                # Combine with model-specific parameters
                param_distributions[pipeline_name] = {**params}
            
        return pipelines, param_distributions

    def hyperparam_search(self, pipelines, param_distributions):
        '''
        Iterates through a dictionary of pipelines,
        finding optimal hyperparameters for each.
        
        parameters:
            pipelines (dict): {pipeline_name: pipeline}
            param_distributions (dict): {pipeline_name : hyperparams}
            
        returns:
            best_models (dict): {model_name: optimal estimator}
            results (pd.DataFrame): summary of training and validation roc_auc,
                                    optimal hyperparameters
        '''
        # Perform RandomizedSearchCV on each pipeline
        results = defaultdict(list)
        
        X_train_ = self.X_train
        
        if self.dim_reduce != True:
            X_train_ = X_train_[self.config.snrpv_vars]

        for name, pipeline in pipelines.items():
            print(f"Tuning {name}...")

            search = RandomizedSearchCV(
                pipeline, param_distributions[name], n_iter=20, cv=5,
                scoring='roc_auc', random_state=self.config.random_state, n_jobs=-1
            )
            search.fit(X_train_, self.y_train)
            self.best_models[name] = search.best_estimator_
            
            train_score = search.score(X_train_, self.y_train)
            valid_score = search.best_score_
            
            results['model'].append(name)
            results['train_score'].append(train_score)
            results['validation_score'].append(valid_score)
            results['best_params'].append(f"{search.best_params_}")
        
        # dataframe of results
        base_results_df = pd.DataFrame(results)
        
        return self.best_models, base_results_df
    
    def plot_base(self, title, cv = False):
        plt.figure()
        
        X_train_ = self.X_train
        
        if self.dim_reduce != True:
            X_train_ = X_train_[self.config.snrpv_vars]
            
        for name, estimator in self.best_models.items():
            if cv:
                pred = cross_val_predict(
                    estimator, 
                    self.X_train, 
                    self.y_train, 
                    cv=5, 
                    method='predict_proba')[:, 1]
            else:
                pred = estimator.predict_proba(X_train_)[:, 1]
                
            if name == 'se_svm': # not sure why this has to be reversed
                fpr, tpr, _ = roc_curve(self.y_train, pred, pos_label=0)
            else:
                fpr, tpr, _ = roc_curve(self.y_train, pred, pos_label=1)
            area = auc(fpr, tpr)
            plt.plot(fpr, tpr, label = name + f' (AUC = {area:.3f})')
            
        plt.xlabel('1 - specificity')
        plt.ylabel('Sensitivity')
        plt.plot([0, 1], [0, 1], color='grey', lw=1.2, linestyle='--')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.legend(loc='lower right')
        plt.title(title)
        plt.show()
            
    def stack_fit(self, best_models):
        '''
        fits the stacking ensemble
        
        parameters:
            best_models (dict): {model_name: optimal estimator}
            
        returns:
            predict_train (np.ndarray): predicted probs of malignant tumor
                                        on the training set
            predict_test (np.ndarray):  predicted probs of malignant tumor
                                        on the test set
        '''
        meta_model = self.config.meta_model
        # Create a Stacking Ensemble Model
        stacking_model = StackingClassifier(
            estimators=[(name, best_models[name]) for name in best_models],
            final_estimator=meta_model,
            cv=5,
            stack_method = 'predict_proba'
        )

        # Train the Stacking Model
        stacking_model.fit(self.X_train, self.y_train)
        predict_train = stacking_model.predict_proba(self.X_train)[:, 1]
        predict_test = stacking_model.predict_proba(self.X_test)[:, 1]
        
        return predict_train, predict_test
    
    