# import relevant libraries
import pandas as pd
import numpy as np
import re
from sklearn.preprocessing import StandardScaler

class Hunters:
    def __init__(
        self, 
        train_dir = 'data/Features_Train.csv', 
        test_dir = 'data/Features_Test.csv'
        ):
        # 5-feature small nodule radiomics-predictive-vector (SN-RPV) weights
        '''
        Weights are obtained from the results of running the following script:
        https://github.com/dr-benjamin-hunter/Small-nodule-radiomics
        '''
        self.weights = {
            'Intercept': -0.009275277,
            'Annulus_GLCM_Entrop_LLL_25HUgl': 0.441113001,
            'Lesion_GLCM_Correl_LLL_25HUgl': 0.101239762,
            'Lesion_GLCM_difVar_LLL_25HUgl': -0.174674002,
            'Lesion_GLCM_InfCo2_LHL_25HUgl': -0.299478100,
            'Lesion_GLCM_InfCo2_LHH_25HUgl': -0.124846039
            }
        self.train = pd.read_csv(train_dir)
        self.test = pd.read_csv(test_dir)
        
    def process_data(self) -> tuple:
        '''
        standardizes column names for training and test set
        performs z-score normalization
        
        returns:
            tuple(train_scaled, test_scaled, train_y, test_y)
                train_scaled (pd.DataFrame): normalized training features
                test_scaled (pd.DataFrame): normalilzed test features
                train_y (pd.Series): training set outcome labels
                test_y (pd.Series): test set outcome labels
        '''
        # Replace spaces and dashes in column names with '.'
        self.test.columns = [re.sub(r'[\s-]', '.', col) for col in self.test.columns]
        
        # selected features
        selected_features = [
            feature for feature in list(self.weights.keys()) if feature != 'Intercept'
            ]
        
        # train x, train y, test x, test y
        train_x = self.train.loc[:, self.train.columns.isin(selected_features)]
        train_y = self.train.loc[:, 'Outcome']
        test_x = self.test.loc[:, self.test.columns.isin(selected_features)]
        test_y = self.test.loc[:, 'Outcome']

        scaler = StandardScaler()
        train_scaled = scaler.fit_transform(train_x)
        test_scaled = scaler.transform(test_x)
        
        # Add a column of ones on the for intercept
        train_scaled = np.hstack([np.ones((train_scaled.shape[0], 1)), train_scaled])
        test_scaled = np.hstack([np.ones((test_scaled.shape[0], 1)), test_scaled])
        
        return train_scaled, test_scaled, train_y, test_y

    def predict_proba(self, data: pd.DataFrame) -> np.ndarray:
        '''
        Calculates logistic regression output
        
        parameters:
            data (pd.DataFrame): training or test set features
            
        returns:
            probs (np.ndarray): predicted probabilities
        '''
        # Calculate the logits and probs
        logits = np.dot(data, list(self.weights.values()))
        probs = 1 / (1 + np.exp(-logits))

        return probs