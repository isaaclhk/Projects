# imports
from sklearn.decomposition import PCA
from sklearn.manifold import SpectralEmbedding
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from scipy.stats import randint, uniform
from sklearn.base import BaseEstimator, TransformerMixin

# set seed for reproducibility
random_state = 6740

# Custom Transformer for Spectral Embedding
class SpectralEmbeddingTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, n_components=10, random_state=random_state):
        self.n_components = n_components
        self.random_state = random_state
        self.embedding_ = None

    def fit(self, X, y=None):
        self.embedding_ = SpectralEmbedding(n_components=self.n_components, random_state=self.random_state)
        self.embedding_.fit(X)
        return self

    def transform(self, X):
        return self.embedding_.fit_transform(X)  # SpectralEmbedding does not support transform(), so we refit.


# Define models and their hyperparameters
models = {
    "svm": (SVC(probability=True, random_state=random_state), {'classifier__C': uniform(0.1, 10), 'classifier__kernel': ['linear', 'rbf']}),
    "rf": (RandomForestClassifier(random_state=random_state), {'classifier__n_estimators': randint(50, 200), 'classifier__max_depth': randint(3, 20)}),
    "knn": (KNeighborsClassifier(), {'classifier__n_neighbors': randint(3, 20), 'classifier__weights': ['uniform', 'distance']}),
    "nb": (GaussianNB(), {})  # No hyperparameters for Naive Bayes
}

# Define the dimensionality reduction techniques 
dim_reductions = {
    "pca": PCA(),
    "se": SpectralEmbeddingTransformer()
}

# Define search space for dimensionality reduction
dim_reduction_params = {
    'dim_reduction__n_components': randint(5, 15)  # Let Random Search pick n_components
}

# define meta model
meta_model = LogisticRegression(penalty = None)

# SN-RPV variables
snrpv_vars = ['Annulus_GLCM_Entrop_LLL_25HUgl', 'Lesion_GLCM_Correl_LLL_25HUgl',
              'Lesion_GLCM_difVar_LLL_25HUgl', 'Lesion_GLCM_InfCo2_LHL_25HUgl',
              'Lesion_GLCM_InfCo2_LHH_25HUgl']