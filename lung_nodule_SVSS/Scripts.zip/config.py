# config.py

# paths to training and test set
paths = {
    'A_path': 'data/Features_Test.csv',
    'B_path': 'data/Features_Train.csv'
}

# preprocessor settings
preprocessor={
    'train_size': 50,
    'alpha': 0.1
    }

# svss params
SVSS = {'p': 0.0015,
        'tau': 1,
        'target_accept': 0.98,
        'n': 3,
        'draws': 10000
}

# random state for reproducibility
random_state=6420

# model params
models = {
    'lasso_logreg': {
        'Cs':50,
        'cv':5,
        'scoring':'roc_auc'
    },
    'comparison': 'loo'
}

# execution settings
main = {
    'load_svss': False,
    'load_logreg_001': False,
    'load_logreg_01': False,
    'load_logreg_1': False,
    'load_logreg_10': False,
    'plot_trace': True
    }   