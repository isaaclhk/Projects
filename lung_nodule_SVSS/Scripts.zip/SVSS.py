# import relevant libraries
import os
import re
import arviz as az
import pymc as pm
from pymc.math import dot, invlogit

import config

# svss
def SVSS(X, y, 
         p=config.SVSS['p'], tau=config.SVSS['tau']):
    print('Performing SVSS...')
    _, n = X.shape

    with pm.Model() as m_svss:
        # prior
        delta = pm.Bernoulli("delta", p=p, shape=n)
        alpha = pm.Normal("alpha", 0, tau=tau, shape=n)
        beta = pm.Deterministic("beta", delta * alpha)

        intercept = pm.Normal("intercept", 0, tau=tau)

        prob = invlogit(intercept + dot(X, beta))
        
        # likelihood
        pm.Bernoulli("y_train", p=prob, observed=y)

        trace = pm.sample(draws=config.SVSS['draws'],
                        target_accept=config.SVSS['target_accept'], 
                        random_seed=config.random_state)
    
    print('') # print empty line for readbility    
    return trace
    
def get_top_vars(trace, cols, n=config.SVSS['n']):
    '''
    filters the summary to get top n variables

    parameters:
        trace: trace output from svss
        n (int): top _ variables to include in the summary
        cols (list): list of column names from the predictor dataset
        
    returns:
        filtered_summary_df (pd.DataFrame):
            az.summary of top n variables
    '''
    print(f'Retrieving top {n} variables...')
    
    # Get the summary DataFrame
    summary_df = az.summary(trace, var_names="delta", hdi_prob=0.95)
    # Define the number of top features to select
    top_n = n
    # Sort the summary DataFrame by the mean values in descending order
    sorted_summary_df = summary_df.sort_values(by='mean', ascending=False)
    # Select the top_n features
    filtered_summary_df = sorted_summary_df.head(top_n)

    # Get the indices of the top_n features
    top_indices = filtered_summary_df.index

    # Map the indices to the feature names
    selected_vars = [cols[int(re.search(r'[0-9]+', idx).group())] for idx in top_indices]
    
    print('') # empty line for readability
                    
    return filtered_summary_df, selected_vars

def save_trace(trace, file_name):
    '''
    saves trace to directory
    
    parameters:
        trace_svss: the trace object
    '''
    # Define the directory and file name
    directory = "saved"
    trace_file = os.path.join(directory, file_name)

    # Create the directory if it doesn't exist
    if not os.path.exists(directory):
        os.makedirs(directory)

    # Save the trace to a file
    az.to_netcdf(trace, trace_file)

    print(f"Trace saved to {trace_file}")
    
def load_trace(file_name):
    # Define the directory and file name
    directory = "saved"
    trace_file = os.path.join(directory, file_name)

    # Load the trace from the file
    if os.path.exists(trace_file):
        trace_svss = az.from_netcdf(trace_file)
        print(f"Trace loaded from {trace_file}")
    else:
        print(f"Trace file {trace_file} does not exist.")
        
    return trace_svss