# import relevant libraries
import arviz as az
from matplotlib import rcParams

from config import main
import SVSS
import models
from preprocessor import Preprocessor
from evaluate_utils import report, plots

def main(load_svss=main['load_svss'],
         load_logreg_001=main['load_logreg_001'],
         load_logreg_01=main['load_logreg_01'],
         load_logreg_1=main['load_logreg_1'],
         load_logreg_10=main['load_logreg_10'],
         plot_trace=main['plot_trace']):
    
    # set matplotlib font
    rcParams['font.family'] = 'cmr10'
    rcParams['axes.unicode_minus'] = False # missing minus sign

    # set font size
    rcParams.update({'font.size': 12})
    
    # instantiate preprocessor
    preprocessor = Preprocessor()
    y_train, y_test = preprocessor.y_train, preprocessor.y_test
    
    if load_svss:
        # load svss trace
        trace_svss = SVSS.load_trace(load_svss)
        # load significant features
        with open('saved/significant_features.txt', 'r') as file:
            significant_features=[var.strip() for var in file]
        print('significant features loaded from saved/significant_features.txt')

    else:
        # get updated datasets with selected features
        X_train_data, _ = preprocessor.update_dataset()
        print(f'Number of significant features identified: {X_train_data.shape[1]}')
        
        # save significant features
        significant_features=list(X_train_data.columns)
        with open('saved/significant_features.txt', 'w') as file:
            for var in significant_features:
                file.write(f'{var}\n')
        print('Significant features saved to saved/significant_features.txt')
        
        # SVSS
        trace_svss = SVSS.SVSS(
            X_train_data, y_train)
        SVSS.save_trace(trace_svss, 'trace_svss.nc')
    
    cols = list(preprocessor.X_train_scaled.columns)    
    svss_summary, selected_vars = SVSS.get_top_vars(
        trace_svss, cols)
    
    # display svss summary for top variables
    print(svss_summary)
    print('') # empty line for readability
    print('<<Final selected features>>')
    for var in selected_vars:
        print(var)
    print('') # empty line for readability
        
    # get final dataset based on selected features
    X_train_final = preprocessor.X_train_scaled[selected_vars]
    X_test_final = preprocessor.X_test_scaled[selected_vars]

    # bayesian logistic regression
    best_trace, best_tau = models.compare_logregs(
        X_train_final, y_train,
        load_logreg_001,
        load_logreg_01,
        load_logreg_1,
        load_logreg_10,
        plot_trace=plot_trace
        )

    # get summary of the optimal model
    print('') # empty line for readability
    print('<<Coefficient statistics for of the best model>>')
    best_logreg_summary = az.summary(
        best_trace, hdi_prob=0.95)
    print(best_logreg_summary)
    
    # find predicted y values from bayesian logreg
    print('') # empty line for readability
    y_preds_train_summary, y_preds_test_summary = models.predict(X_train_final, 
                                                    y_train, 
                                                    X_test_final, 
                                                    y_test,
                                                    best_tau)
    
    y_preds_train = y_preds_train_summary['mean'].values
    y_preds_test = y_preds_test_summary['mean'].values
    
    # dataset with significant features from first of layer feature selection
    X_train_data = preprocessor.X_train_scaled[significant_features]
    X_test_data = preprocessor.X_test_scaled[significant_features]
    
    # perform lasso logistic regression
    y_preds_train_lasso, y_preds_test_lasso = models.lasso_logreg(
        X_train_data, X_test_data, y_train) 
    
    # evaluation
    print('') # empty line for readability
    train_stats, test_stats = report(
        y_train, y_test, y_preds_train, y_preds_test, 
           'Bayesian Logistic Regression')
    train_stats_lasso, test_stats_lasso = report(
        y_train, y_test, y_preds_train_lasso, y_preds_test_lasso, 
           'Lasso Logistic Regression')
    # combined ROC plots
    plots(train_stats, test_stats, train_stats_lasso, test_stats_lasso)
    
if __name__ == '__main__':
    main()