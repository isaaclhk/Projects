# import relevant libraries
import pandas as pd
import numpy as np
import statsmodels.api as sm
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tqdm import tqdm
from statsmodels.tools.sm_exceptions import PerfectSeparationError


import config

class Preprocessor():
    def __init__(self, 
                 A_path=config.paths['A_path'],
                 B_path=config.paths['B_path']
                 ):
        A = pd.read_csv(A_path) 
        B = pd.read_csv(B_path)
        
        # consistent column names
        A.columns = B.columns
        
        # combine datasets
        df = pd.concat([A, B])
        
        # X y
        X = df.drop(columns = ['ID', 'Outcome'])
        y = df['Outcome']
        
        # train test split
        X_train, X_test, \
        self.y_train, self.y_test = train_test_split(
            X, y, train_size=config.preprocessor['train_size'], stratify=y, 
            random_state = config.random_state)

        # scaled data
        scaler = StandardScaler().set_output(transform='pandas')
        self.X_train_scaled = scaler.fit_transform(X_train)
        self.X_test_scaled = scaler.transform(X_test)
        
        # print y distribution
        print(
            "Training set label distribution:\n", self.y_train.value_counts())
        print(
            "Test set label distribution:\n", self.y_test.value_counts())

    def _univar_logregs(self):
        """
        Perform univariable logistic regression on all variables of the dataset to get a series of p-values.
        
        Returns:
        list: A list of p-values for each feature in the dataset.
        """
        p_values = []
        
        # Perform univariable logistic regression for each feature
        for feature in tqdm(self.X_train_scaled.columns):
            X_ = self.X_train_scaled[[feature]]
            X_ = sm.add_constant(X_)
            model = sm.Logit(self.y_train, X_).fit(disp=0, method='bfgs')
            
            # Check if model.pvalues has at least two elements
            if len(model.pvalues) > 1:
                p_values.append(model.pvalues.iloc[1]) # Exclude the intercept term
            else:
                print(f"Absent p-val for {feature}. This feature will be excluded.")
                p_values.append(1) # this particular feature has many equal values
                
        return p_values

    def _benjamini_hochberg(self, p_values, 
                            alpha):
        """
        Perform the Benjamini-Hochberg procedure to control the False Discovery Rate (FDR).
        
        Parameters:
        p_values (list): List of p-values from multiple hypothesis tests.
        alpha (float): Desired FDR level.
        
        Returns:
        list: A list of booleans indicating which p-values are significant.
        """
        # Number of tests
        m = len(p_values)
        
        # Sort p-values and get their corresponding indices
        sorted_indices = np.argsort(p_values)
        sorted_pvals = np.array(p_values)[sorted_indices]
        
        # Calculate critical values
        critical_values = np.arange(1, m+1) / m * alpha
        
        # Find the largest p-value that is less than or equal to its corresponding critical value
        significant = sorted_pvals <= critical_values
        
        # Ensure that if a p-value is significant, all smaller p-values are also significant
        significant = np.maximum.accumulate(significant[::-1])[::-1]
        
        # Create a list of booleans indicating which p-values are significant
        result = np.zeros(m, dtype=bool)
        result[sorted_indices] = significant
        
        feature_names = list(self.X_train_scaled.columns)

        # extract names of significant features
        significant_features = [
            feature for feature, is_significant in zip(feature_names, significant) if is_significant]
        
        return significant_features
    
    def update_dataset(self, alpha=config.preprocessor['alpha']):
        print('Performing first layer of feature selection...')
        p_values = self._univar_logregs()
        significant_features = self._benjamini_hochberg(p_values, alpha)
        print('') # print empty line for readability
        
        return self.X_train_scaled[significant_features], self.X_test_scaled[significant_features]
    

