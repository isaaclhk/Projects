# imports
import numpy as np
import arviz as az
import pymc as pm
import matplotlib.pyplot as plt
from pymc.math import dot, invlogit
from sklearn.linear_model import LogisticRegressionCV

from SVSS import save_trace, load_trace
import config

def bayes_logreg(X, y, tau):
    '''
    Method to run bayesian logistic regression
    
    parameters:
        X (pd.DataFrame): dataset with selected features
        y (pd.Series): series of target variables
        tau (float): tau parameter for normal priors
        
    Returns:
        tuple:
            trace: The trace of the sampled values.
            logreg_m (pm.Model): The PyMC3 model object.

    '''
    print(f'Running bayesian logistic regression at tau={tau}..')

    with pm.Model() as logreg_m:
        X_data = pm.Data('X', X)
        y_data = pm.Data('y', y)
        alpha = pm.Normal("intercept", mu=0, tau=tau)
        betas = pm.Normal("beta", mu=0, tau=tau, shape=X.shape[1])

        p = invlogit(alpha + dot(X_data, betas))
        
        pm.Bernoulli('y_hat', p=p, observed=y_data)

        trace = pm.sample(5000, target_accept=0.98, 
                          random_seed=config.random_state)
        
        pm.compute_log_likelihood(trace)

    return trace, logreg_m

def compare_logregs(X, y,
                    load_logreg_001,
                    load_logreg_01,
                    load_logreg_1,
                    load_logreg_10,
                    plot_trace):
    
    '''
    Compares the bayesian logistic regressions
    with different prior parameter taus.
    The default mode of comparison is 'LOO'.
    
    parameters:
        X (pd.DataFrame): Dataset of predictor variables
        y (pd.Series): Target labels
        load_logreg_* (str): filename of saved trace, or False
        plot_trace (Bool): az.plot_trace(trace)?
        
    returns:
        best_trace: trace object of the optimal model
        best_tau (float): tau parameter of the optimal model
    '''
    logreg_results = {}
    tau_values = [0.01, 0.1, 1, 10]
    load_logreg_vars = [
        load_logreg_001, 
        load_logreg_01, 
        load_logreg_1, 
        load_logreg_10
        ]
    trace_names = [
        'trace_logreg_001.nc', 
        'trace_logreg_01.nc', 
        'trace_logreg_1.nc', 
        'trace_logreg_10.nc'
        ]

    print('Obtaining traces for logistic regression models..')
    for tau, load_logreg, trace_name in zip(
        tau_values, load_logreg_vars, trace_names):
        if load_logreg: # load trace. else, run _bayes_logreg
            logreg_results[trace_name]=load_trace(load_logreg)
        else:
            logreg_results[trace_name], _ =bayes_logreg(
                X, y, tau=tau)
            save_trace(logreg_results[trace_name], trace_name)
    
    print('') # empty line for readability
    comparison=az.compare(
        logreg_results, ic=config.models['comparison'])
    
    best_trace_name = comparison.index[0]
    best_tau = tau_values[trace_names.index(best_trace_name)]
    best_trace = logreg_results[best_trace_name]

    print('<<Comparison of bayesian logistic regression models>>')
    print(comparison)
    
    # trace plots
    if plot_trace:
        for name, t in logreg_results.items():
            az.plot_trace(t)
            plt.tight_layout()
            plt.suptitle(name)
    
    return best_trace, best_tau

def predict(X_train, y_train, X_test, y_test, tau):
    '''
    refits a bayesian logistic regression model with the given tau
    
    returns:
        tuple: 
            (y_preds_train_summary, y_preds_test_summary)
            az.summary of predicted target labels for train and test set
    '''
    trace, m = bayes_logreg(
        X_train, y_train, tau)
    with m: # test on test set
        ppc_train=pm.sample_posterior_predictive(trace, 
                                           random_seed=config.random_state,
                                           predictions=True)
        pm.set_data({'X': X_test, 'y': y_test})
        ppc_test=pm.sample_posterior_predictive(trace, 
                                           random_seed=config.random_state,
                                           predictions=True)
    
    y_preds_train_summary = az.summary(ppc_train.predictions, hdi_prob=0.95)
    y_preds_test_summary = az.summary(ppc_test.predictions, hdi_prob=0.95)
    
    return y_preds_train_summary, y_preds_test_summary

def lasso_logreg(X_train, X_test, y_train, 
                 params=config.models['lasso_logreg']):
    # lasso logreg with cv
    lasso_logreg = LogisticRegressionCV(
        Cs=params['Cs'], 
        cv=params['cv'],  
        penalty='l1', 
        solver='saga',  # solver that supports L1 regularization
        scoring=params['scoring'],
        max_iter=10000,
        random_state=config.random_state
    )

    # Fit the model
    lasso_logreg.fit(X_train, y_train)
    
    # Print the optimal C value
    print(f'Optimal C value: {lasso_logreg.C_[0]:.3f}')

    # Get the coefficients
    coefs = lasso_logreg.coef_[0]
    
    # non-zero coefficients
    non_zero_coefs_idx=np.where(coefs != 0)[0]
    non_zero_coefs=coefs[non_zero_coefs_idx]
    selected_features= X_train.columns[non_zero_coefs_idx]
    
    print('Features Selected by Lasso Logistic Regression:')
    for var, coef in zip(selected_features, non_zero_coefs):
        print(f'{var}: {coef:.3f}')

    # predict target labels
    y_pred_train = lasso_logreg.predict_proba(X_train)[:, 1]
    y_pred_test = lasso_logreg.predict_proba(X_test)[:, 1]
    
    return y_pred_train, y_pred_test