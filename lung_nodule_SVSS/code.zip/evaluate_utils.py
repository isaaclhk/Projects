# import relevant libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score, roc_curve
from sklearn.metrics import classification_report, accuracy_score

import config
    
# Calculate Youden Index and optimal cut-off point
def _youden_threshold(y_true: pd.Series, probs:  np.ndarray) -> float:
    '''
    Calculates the optimal threshold by maximizing the youden index
    
    parameters:
        y_true (pd.Series): true outcome labels
        probs (np.ndarray): predicted probabilities
        
    returns:
        optimal_threshold (float): 
            optimal probability cut-off corresponding to max youden index
    '''
    fpr, tpr, thresholds = roc_curve(y_true, probs)
    youden_index = tpr - fpr
    max_youden_index = np.argmax(youden_index)
    optimal_threshold = thresholds[max_youden_index]
    
    return optimal_threshold

# method to evaluate sn-rpv
def _eval(
    y_true: pd.Series, 
    probs: np.ndarray,
    threshold: float, 
    title: str,
    n_bootstraps: int=1000, 
    random_seed: int=config.random_state) -> dict:
    '''
    Evaluate the performance of a binary classifier using bootstrapping.
    
    Parameters:
        y_true (pd.Series): true outcome labels.
        probs (np.ndarray): predicted probabilities.
        threshold (float): threshold for converting probabilities to class labels.
        title (str): Title for the ROC curve plot.
        n_bootstraps (int), optional:
            Number of bootstrap samples to generate (default is 1000).
        random_seed (int), optional:
            Seed for random number generator to ensure reproducibility (default is 1234).

    Returns:
        dict
        - 'auc': Tuple containing mean AUC, lower 95% CI, and upper 95% CI.
        - 'acc': Tuple containing mean accuracy, lower 95% CI, and upper 95% CI.
        - 'classification_report': Classification report as a string.
    '''
    # set seed for reproducibility
    rng = np.random.RandomState(random_seed)
    
    # empty lists to record bootstrapped metrics
    bootstrapped_auc = []
    bootstrapped_acc = []
    
    # Convert probabilities to class labels
    y_pred = np.array([1 if prob > threshold else 0 for prob in probs])
    
    # precision, recall, f1score
    report = classification_report(
        y_true, y_pred, target_names = ['benign', 'malignant']
        )
    
    # function to calculate mean, lower and upper ci
    def _mean_ci(boostrapped_scores):
        sorted_scores = np.array(boostrapped_scores)
        sorted_scores.sort()
        # Calculate mean and 95% confidence intervals
        mean = np.mean(boostrapped_scores)
        lwr = sorted_scores[int(0.025 * len(sorted_scores))]
        upr = sorted_scores[int(0.975 * len(sorted_scores))]
    
        return mean, lwr, upr
    
    for _ in range(n_bootstraps):
        while True:
            # Bootstrap by sampling with replacement on the prediction indices
            indices = rng.randint(0, len(probs), len(probs))
            if len(np.unique(y_true[indices])) == 2: # ensures both labels present
                break
        auc = roc_auc_score(y_true[indices], probs[indices])
        bootstrapped_auc.append(auc)
        
        accuracy = accuracy_score(y_true[indices], y_pred[indices])
        bootstrapped_acc.append(accuracy)
    
    mean_auc, lwr_auc, upr_auc = _mean_ci(bootstrapped_auc)
    mean_acc, lwr_acc, upr_acc = _mean_ci(bootstrapped_acc)
    
    # plot roc curve
    fpr, tpr, _ = roc_curve(y_true, probs)
    plt.figure()
    plt.plot(fpr, tpr, color='Navy', lw=1.2, label=f'ROC curve')
    plt.plot([0, 1], [0, 1], color='grey', lw=1.2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('1 - specificity')
    plt.ylabel('Sensitivity')
    plt.text(
        0.3, 0.33, 
        f'Area = {mean_auc:.3f} [95% CI: {lwr_auc:.3f}, {upr_auc:.3f}]', 
        rotation = 36
        )
    plt.title(title)
    plt.legend(loc='lower right')
    plt.show()
    
    return {
        'auc': (mean_auc, lwr_auc, upr_auc), 
        'acc': (mean_acc, lwr_acc, upr_acc),
        'classification_report': report,
        'fpr': fpr,
        'tpr': tpr
        }
    
def _evaluate(y_train, y_test, predict_train, predict_test, 
              model):
    '''
    params:
        model (str): name of the model in plot title
    
    calculates threshold and performs evaluation on training and test sets
    refer to _eval
    '''
    # identify optimal threshold
    threshold = _youden_threshold(y_train, predict_train)
    
    # evaluate model
    train_eval = _eval(
        y_train.values, 
        predict_train,
        threshold,
        f'{model} AUC-ROC (Training set)')
    
    test_eval = _eval(
        y_test.values, 
        predict_test,
        threshold,
        f'{model} AUC-ROC (Test set)')
    
    return threshold, train_eval, test_eval

def report(y_train, y_test, predict_train, predict_test, 
           model: str):
    '''
    Prints the 95% confidence interval for AUC-ROC and accuracy scores
    prints the classification report
    
    returns:
        tuple:
            train and test statistics
    '''
    print(f'Evaluating {model}...')
    
    threshold, train_eval, test_eval = _evaluate(
        y_train, y_test, predict_train, predict_test, model)
    
    train_mean_auc, train_lwr_auc,  train_upr_auc = train_eval['auc']
    train_mean_acc, train_lwr_acc, train_upr_acc = train_eval['acc']
    train_report = train_eval['classification_report']
    train_fpr, train_tpr = train_eval['fpr'], train_eval['tpr']
    
    test_mean_auc, test_lwr_auc,  test_upr_auc = test_eval['auc']
    test_mean_acc, test_lwr_acc, test_upr_acc = test_eval['acc']
    test_report = test_eval['classification_report']
    test_fpr, test_tpr = test_eval['fpr'], test_eval['tpr']
    # Print the results
    print(
    f'Prediction threshold identified by maximizing youden index: {
        round(threshold, 3)
        }'
    )
                    
    print('=== training set===')
    print(
        f'AUC Score [95% CI]: {train_mean_auc:.3f} [{train_lwr_auc:.3f}, {train_upr_auc:.3f}]'
        )
    print(
        f'Accuracy [95% CI]: {train_mean_acc:.3f} [{train_lwr_acc:.3f}, {train_upr_acc:.3f}]'
        )
    print('Classification report:')
    print(train_report)
    print('')
    
    print('=== test set ===') 
    print(
        f'AUC Score [95% CI]: {test_mean_auc:.3f} [{test_lwr_auc:.3f}, {test_upr_auc:.3f}]'
        )
    print(
        f'Accuracy [95% CI]: {test_mean_acc:.3f} [{test_lwr_acc:.3f}, {test_upr_acc:.3f}]'
        )
    print('Classification report:')
    print(test_report)
    
    # return for plotting
    return (
        train_fpr, train_tpr, train_mean_auc, train_lwr_auc, train_upr_auc
        ), (
        test_fpr, test_tpr, test_mean_auc, test_lwr_auc, test_upr_auc)

def _plot_combined_roc(
    bayes_fpr, bayes_tpr, bayes_mean_auc, bayes_lwr_auc, bayes_upr_auc,
    lasso_fpr, lasso_tpr, lasso_mean_auc, lasso_lwr_auc, lasso_upr_auc, 
    set
    ):
    '''
    plot roc curves for bayesian and LASSO logistic regression
    
    parameters:
        prefixed with bayes: stats of bayes logistic regression
        prefixed with lasso: stats of LASSO logistic regression
        set (string): 'training' or 'test' set
    '''        
    plt.figure()

    # bayes logreg
    plt.plot(bayes_fpr, bayes_tpr, lw=1.2, 
             label=f'Bayes (AUC = {bayes_mean_auc:.3f}'
             f' [95% CI: {bayes_lwr_auc:.3f} to {bayes_upr_auc:.3f}])'
             )
    # lasso logreg
    plt.plot(lasso_fpr, lasso_tpr, lw=1.2, 
             label=f'LASSO (AUC = {lasso_mean_auc:.3f}' 
             f' [95% CI: {lasso_lwr_auc:.3f} to {lasso_upr_auc:.3f}])'
             )

    plt.plot([0, 1], [0, 1], color='grey', lw=1.2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('1 - specificity')
    plt.ylabel('Sensitivity')
    plt.title(f'AUC-ROC of Bayesian and LASSO logistic regression ({set} set)')
    plt.legend(loc='lower right')
    plt.show()
    
def plots(train_stats, test_stats, train_stats_lasso, test_stats_lasso):
    '''
    plots the combined roc plots for training and test sets
    
    parameters:
        outputs from report method
    '''
        # extract stats for plotting
    bayes_fpr_train, bayes_tpr_train, bayes_mean_auc_train, \
        bayes_lwr_auc_train, bayes_upr_auc_train = train_stats
    bayes_fpr_test, bayes_tpr_test, bayes_mean_auc_test, \
        bayes_lwr_auc_test, bayes_upr_auc_test = test_stats
    lasso_fpr_train, lasso_tpr_train, lasso_mean_auc_train, \
        lasso_lwr_auc_train, lasso_upr_auc_train = train_stats_lasso
    lasso_fpr_test, lasso_tpr_test, lasso_mean_auc_test, \
        lasso_lwr_auc_test, lasso_upr_auc_test = test_stats_lasso
    # plot roc
    _plot_combined_roc(bayes_fpr_train, bayes_tpr_train, bayes_mean_auc_train,
        bayes_lwr_auc_train, bayes_upr_auc_train, 
        lasso_fpr_train, lasso_tpr_train, lasso_mean_auc_train,
        lasso_lwr_auc_train, lasso_upr_auc_train, 'training')
    _plot_combined_roc(bayes_fpr_test, bayes_tpr_test, bayes_mean_auc_test,
        bayes_lwr_auc_test, bayes_upr_auc_test, 
        lasso_fpr_test, lasso_tpr_test, lasso_mean_auc_test,
        lasso_lwr_auc_test, lasso_upr_auc_test, 'test')